console.log("page loading...");


var message = document.querySelector("#messagealert");

function clickcity() {  
    alert("Loading Weather Report");
}

function removealert() {
    
    message.remove();
    
}

function celsiusToFahrenheit(temp) {
    //var fahrenheit = 9 / 5 * temp + 32;
    //return fahrenheit;

   return Math.round(9 / 5 * temp + 32);
  }

function fahrenheitToCelsius(temp) {
    //var celsius = 5 / 9 * (temp - 32);
    //return celsius;
    return Math.round(5 / 9 * (temp - 32));

  }

function convertdegrees(element){
    console.log(element.value);
    for(var i=1; i<9; i++){
        var tempscan = document.querySelector('#temp' + i);
        var tempval = parseInt(tempscan.innerText);

        if(element.value == "°C"){
            tempscan.innerText = fahrenheitToCelsius(tempval);
        }
        else{
            tempscan.innerText = celsiusToFahrenheit(tempval);
        }
    }
    
}